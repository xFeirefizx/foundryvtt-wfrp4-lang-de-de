TODO: Instructions for custom tables
