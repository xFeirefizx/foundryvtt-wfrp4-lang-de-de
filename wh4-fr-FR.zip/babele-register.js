
Hooks.once('init', () => {
  
  if(typeof Babele !== 'undefined') {
		
		Babele.get().register({
			module: 'WH4-fr-translation',
			lang: 'fr',
			dir: 'compendium'
		});
    
    Babele.get().registerConverters({
      "career_skills": (skills_list) => {
        console.log( game.i18n.localize( "Any" ) );
        var compendium = game.packs.find(p => p.collection === 'wfrp4e.skills');
        var i;
        var len = skills_list.length;
        var re  = /(.*)\((.*)\)/i;
        for (i = 0; i < len; i++) {
          var transl = compendium.i18nName( skills_list[i] );
          if ( transl == skills_list[i] ) {            
            var res = re.exec( skills_list[i]);
            if (res) { 
              //console.log("Matched/split:", res[1], res[2]);
              var subword = game.i18n.localize(res[2].trim() );
              var s1 = res[1].trim() + " ()";
              var translw = compendium.i18nName( s1 );
              if (translw != transl) {
                var res2 = re.exec(translw);
                transl = res2[1] + "(" + subword  + ")";
              } else {
                s1 = res[1].trim() + " ( )";
                translw = compendium.i18nName( s1 );
                var res2 = re.exec(translw);
                transl = res2[1] + "(" + subword  + ")";
              }  
            }
          }
          skills_list[i] = transl;
        }
        return skills_list;      
      },
      "career_talents": (talents_list) => { 
        var compendium = game.packs.find(p => p.collection === 'wfrp4e.talents');
        var i;
        var len = talents_list.length;
        var re  = /(.*)\((.*)\)/i;
        for (i = 0; i < len; i++) {
          var transl = compendium.i18nName( talents_list[i] );
          if ( transl == talents_list[i] ) {            
            var res = re.exec( talents_list[i]);
            if (res) { 
              //console.log("Matched/split:", res[1], res[2]);
              var subword = game.i18n.localize(res[2].trim() );
              var s1 = res[1].trim(); // No () in talents table
              var translw = compendium.i18nName( s1 );
              if (translw != transl) {
                transl = translw + "(" + subword  + ")";
              } else {
                s1 = res[1].trim() + " ( )";
                translw = compendium.i18nName( s1 );
                var res2 = re.exec(translw);
                transl = res2[1] + "(" + subword  + ")";
              }  
            }
          }
          talents_list[i] = transl;
        }
        return talents_list;      
      },
      // To avoid duplicateing class for all careers
      "generic_localization": (value) => { 
        if ( value )
          return game.i18n.localize( value.trim() );
      },
      "trapping_qualities_flaws": (value) => {
        if ( value ) { 
          var list = value.split( "," );
          var i=0;
          var re  = /(.*) (\d+)/i;        
          for (i=0; i<list.length; i++) {
            var splitted = re.exec( list[i].trim() );
            if ( splitted ) {
              //console.log("FOund:", splitted[0], splitted[1], splitted[2] );
              list[i] = game.i18n.localize( splitted[1] ) + " " + splitted[2];
            } else { 
              list[i] = game.i18n.localize( list[i].trim() ) ;
            }
          }
          return list.toString();
        }
      },
      // Search back in careers the translated name of the groupe (as it is the name of the level career itself)
      "career_careergroup": (value) => { 
        var compendium = game.packs.find(p => p.collection === 'wfrp4e.careers');
        return compendium.i18nName( value );
      }
    });      
  }
  
} );
