Hooks.once("init", function() {
	CONFIG.wfrp4e.supportedLanguages["fr"] = "fr";
})
